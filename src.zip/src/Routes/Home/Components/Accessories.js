import React from "react";
import '../../../css/Home/home-accessories.css';

export function Accessories(){
    return(
        <div class="v2_1189">
            <div class="v2_1190"></div>
            <div class="v2_1191"></div>
            <div class="v2_1192"></div>
            <div class="v2_1193"></div>
            <div class="v2_1194"></div>
            <div class="v2_1195"></div>
            <div class="v2_1196"></div>
            <div class="v2_1197"></div>
            <div class="v2_1198"></div>
            <div class="v2_1199"></div>
            <div class="v2_1200"></div>
            <div class="v2_1201"></div>
            <div class="v2_1202"></div>
            <div class="v2_1203"></div>
            <div class="v2_1204"></div>
            <div class="v2_1205"></div>
            <div class="v2_1206"></div>
            <div class="v2_1207"></div>
            <div class="v2_1208"></div>
            <div class="v2_1209"></div>
            <div class="v2_1210"></div>
            <div class="v2_1211"></div>
            <div class="v2_1212"></div>
            <div class="v2_1213"></div>
            <div class="v2_1214"></div>
            <div class="v2_1215"></div>
            <div class="v2_1216"></div>
            <div class="v2_1217"></div>
            <div class="v2_1218"></div>
            <div class="v2_1219"></div>
            <div class="v2_1220"></div>
            <div class="v2_1221"></div>
            <div class="v2_1222"></div>
            <div class="v2_1223"></div>
            <div class="v2_1224"></div>
            <div class="v2_1225"></div>
            <div class="v2_1226"></div>
            <div class="v2_1227"></div>
            <div class="v2_1228"></div>
            <div class="v2_1229"></div>
            <div class="v2_1230"></div>
            <div class="v2_1231"></div>
            <div class="v2_1232"></div>
            <div class="v2_1233"></div>
            <div class="v2_1234"></div>
            <div class="v2_1235"></div>
            <div class="v2_1236"></div>
            <div class="v2_1237"></div>
            <div class="v2_1238"></div>
            <div class="v2_1239"></div>
        </div>
    );
}