import React,{Component} from "react";
import {HomePresenter} from "./Routes/Home/HomePresenter";
import {Mypage_Home_Presenter} from "./Routes/Mypage/MypagePresenter";
import {Route,Router} from "react-router-dom";
import {Header} from "./Routes/Home/Components/Header";
class App extends Component{
  render(){
    return(
      <>
      <Header />
      <Router>
        <Route path="/" exact={true} component={HomePresenter}/>
        <Route path="/my" component={Mypage_Home_Presenter}/>
      </Router>
      </>
    );
  }
}

export default App;
